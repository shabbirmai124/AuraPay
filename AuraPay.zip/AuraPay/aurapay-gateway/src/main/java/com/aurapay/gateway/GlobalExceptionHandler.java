package com.aurapay.gateway;

import org.springframework.boot.web.reactive.error.ErrorWebExceptionHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Configuration
public class GlobalExceptionHandler {

    @Bean
    @Order(-1)
    public ErrorWebExceptionHandler globalErrorWebExceptionHandler() {
        return (exchange, ex) -> {
            exchange.getResponse().setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
            exchange.getResponse().getHeaders().setContentType(MediaType.APPLICATION_JSON);

            String message = ex.getMessage() != null ? ex.getMessage() : "Unknown error";
            String jsonError = String.format("{\"error\": \"%s\"}", message.replace("\"", "\\\""));

            return exchange.getResponse().writeWith(Mono.just(exchange.getResponse()
                    .bufferFactory().wrap(jsonError.getBytes())));
        };
    }
}
