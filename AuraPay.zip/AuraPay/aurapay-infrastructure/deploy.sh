#!/bin/bash
# Apply all Kubernetes manifests

echo "Applying Kubernetes manifests..."
kubectl apply -f kubernetes/postgres-statefulset.yaml
kubectl apply -f kubernetes/kafka-deployment.yaml
kubectl apply -f kubernetes/auth-deployment.yaml
kubectl apply -f kubernetes/ingress.yaml

echo "Deployment complete."
