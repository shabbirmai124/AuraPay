# AuraPay Infrastructure

This directory contains the Kubernetes manifests and deployment scripts for the AuraPay platform.

## Contents

- `kubernetes/`: Contains YAML manifests for deployments, services, and ingress.
- `deploy.sh`: logical Shell script to apply all manifests.

## Prerequisites

- Local Kubernetes cluster (e.g., Minikube, Docker Desktop K8s).
- `kubectl` configured.

## Usage

Run the deployment script:
```bash
./deploy.sh
```
