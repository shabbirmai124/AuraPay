package com.aurapay.transaction.repository;

import com.aurapay.transaction.entity.AurapayTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface TransactionRepository extends JpaRepository<AurapayTransaction, Long> {
    Optional<AurapayTransaction> findByTransactionId(String transactionId);

    Optional<AurapayTransaction> findByIdempotencyKey(String idempotencyKey);
}
