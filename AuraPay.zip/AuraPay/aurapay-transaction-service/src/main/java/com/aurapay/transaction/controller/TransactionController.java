package com.aurapay.transaction.controller;

import com.aurapay.transaction.entity.AurapayTransaction;
import com.aurapay.transaction.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService service;

    @PostMapping
    public ResponseEntity<AurapayTransaction> initiateTransaction(@RequestBody AurapayTransaction transaction) {
        return ResponseEntity.ok(service.initiateTransaction(transaction));
    }

    @GetMapping("/{transactionId}")
    public ResponseEntity<AurapayTransaction> getTransaction(@PathVariable String transactionId) {
        return ResponseEntity.ok(service.getTransaction(transactionId));
    }
}
