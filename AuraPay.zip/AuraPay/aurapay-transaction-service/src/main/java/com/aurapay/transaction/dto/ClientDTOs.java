package com.aurapay.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.List;

public class ClientDTOs {
    // Shared DTOs container for simplicity
}

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class FraudContext {
    private String userId;
    private BigDecimal amount;
    private String currency;
    private String ipAddress;
    private String deviceId;
}

@Data
@NoArgsConstructor
@AllArgsConstructor
class FraudEvaluationResult {
    private double score;
    private String decision; // AUTO_APPROVE, etc.
    private String reason;
}

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
class LedgerTransactionRequest {
    private String transactionId;
    private String description;
    private List<LedgerEntryRequest> entries;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LedgerEntryRequest {
        private Long walletId;
        private BigDecimal amount;
        private String type;
        private String currency;
        private String referenceId;
    }
}
