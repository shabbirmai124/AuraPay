package com.aurapay.transaction.client;

import com.aurapay.transaction.dto.LedgerTransactionRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "aurapay-ledger-service")
public interface LedgerClient {
    @PostMapping("/ledger/transactions")
    Object recordTransaction(@RequestBody LedgerTransactionRequest request); // Object or specific DTO
}
