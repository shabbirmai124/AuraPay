package com.aurapay.transaction.client;

import com.aurapay.transaction.dto.FraudContext;
import com.aurapay.transaction.dto.FraudEvaluationResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "aurapay-fraud-service")
public interface FraudClient {
    @PostMapping("/fraud/check")
    FraudEvaluationResult checkFraud(@RequestBody FraudContext context);
}
