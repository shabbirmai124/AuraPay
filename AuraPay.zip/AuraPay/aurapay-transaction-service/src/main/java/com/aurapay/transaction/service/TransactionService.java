package com.aurapay.transaction.service;

import com.aurapay.transaction.entity.AurapayTransaction;
import com.aurapay.transaction.events.TransactionEventPublisher;
import com.aurapay.transaction.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.UUID;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository repository;

    @Autowired
    private TransactionEventPublisher eventPublisher;

    @Autowired
    private TransactionStateMachine stateMachine;

    @Autowired
    private com.aurapay.transaction.client.FraudClient fraudClient;

    @Autowired
    private com.aurapay.transaction.client.LedgerClient ledgerClient;

    @Transactional
    public AurapayTransaction initiateTransaction(AurapayTransaction transaction) {
        if (transaction.getIdempotencyKey() != null
                && repository.findByIdempotencyKey(transaction.getIdempotencyKey()).isPresent()) {
            return repository.findByIdempotencyKey(transaction.getIdempotencyKey()).get();
        }

        // 1. Initial Save
        transaction.setTransactionId(UUID.randomUUID().toString());
        transaction.setStatus(AurapayTransaction.TransactionStatus.INITIATED);
        AurapayTransaction saved = repository.save(transaction);

        // 2. Fraud Check
        try {
            com.aurapay.transaction.dto.FraudContext fraudContext = com.aurapay.transaction.dto.FraudContext.builder()
                    .userId(String.valueOf(transaction.getUserId())) // Assuming userId is Long
                    .amount(transaction.getAmount())
                    .currency(transaction.getCurrency())
                    .ipAddress("127.0.0.1") // Placeholder, should come from context
                    .deviceId("unknown")
                    .build();

            com.aurapay.transaction.dto.FraudEvaluationResult fraudResult = fraudClient.checkFraud(fraudContext);
            
            if ("AUTO_BLOCK".equals(fraudResult.getDecision())) {
                saved.setStatus(AurapayTransaction.TransactionStatus.FAILED);
                saved.setFailureReason("Fraud Check Failed: " + fraudResult.getReason());
                return repository.save(saved);
            } else if ("MANUAL_REVIEW".equals(fraudResult.getDecision())) {
                saved.setStatus(AurapayTransaction.TransactionStatus.PENDING); // Or similar
                return repository.save(saved);
            }
        
        } catch (Exception e) {
            // Fallback or retry logic
            saved.setStatus(AurapayTransaction.TransactionStatus.FAILED);
            saved.setFailureReason("Fraud Service Unavailable: " + e.getMessage());
            return repository.save(saved);
        }

        // 3. Ledger Recording
        try {
            // Create simplified Debit/Credit entries for the ledger
            // Logic: Debit Sender (Wallet A), Credit Receiver (Wallet B)
            java.util.List<com.aurapay.transaction.dto.LedgerTransactionRequest.LedgerEntryRequest> entries = new java.util.ArrayList<>();
            
            // Debit Sender
            entries.add(com.aurapay.transaction.dto.LedgerTransactionRequest.LedgerEntryRequest.builder()
                    .walletId(transaction.getSenderWalletId())
                    .amount(transaction.getAmount())
                    .type("DEBIT")
                    .currency(transaction.getCurrency())
                    .referenceId(saved.getTransactionId())
                    .build());

            // Credit Receiver
            entries.add(com.aurapay.transaction.dto.LedgerTransactionRequest.LedgerEntryRequest.builder()
                    .walletId(transaction.getReceiverWalletId()) 
                    .amount(transaction.getAmount())
                    .type("CREDIT")
                    .currency(transaction.getCurrency())
                    .referenceId(saved.getTransactionId())
                    .build());

            com.aurapay.transaction.dto.LedgerTransactionRequest ledgerRequest = com.aurapay.transaction.dto.LedgerTransactionRequest.builder()
                    .transactionId(saved.getTransactionId())
                    .description("Transfer from " + transaction.getSenderWalletId())
                    .entries(entries)
                    .build();

            ledgerClient.recordTransaction(ledgerRequest);
            
            saved.setStatus(AurapayTransaction.TransactionStatus.COMPLETED);

        } catch (Exception e) {
            saved.setStatus(AurapayTransaction.TransactionStatus.FAILED);
            saved.setFailureReason("Ledger Recording Failed: " + e.getMessage());
            return repository.save(saved);
        }

        eventPublisher.publishTransactionCreated(saved);

        return repository.save(saved);
    }

    public AurapayTransaction getTransaction(String transactionId) {
        return repository.findByTransactionId(transactionId)
                .orElseThrow(() -> new RuntimeException("Transaction not found"));
    }
}
