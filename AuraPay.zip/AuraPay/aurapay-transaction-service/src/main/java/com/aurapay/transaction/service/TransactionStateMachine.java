package com.aurapay.transaction.service;

import com.aurapay.transaction.entity.AurapayTransaction;
import com.aurapay.transaction.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TransactionStateMachine {

    @Autowired
    private TransactionRepository repository;

    @Transactional
    public AurapayTransaction transition(String transactionId, AurapayTransaction.TransactionStatus newStatus) {
        AurapayTransaction transaction = repository.findByTransactionId(transactionId)
                .orElseThrow(() -> new RuntimeException("Transaction not found"));

        if (!isValidTransition(transaction.getStatus(), newStatus)) {
            throw new RuntimeException("Invalid state transition from " + transaction.getStatus() + " to " + newStatus);
        }

        transaction.setStatus(newStatus);
        return repository.save(transaction);
    }

    private boolean isValidTransition(AurapayTransaction.TransactionStatus current,
            AurapayTransaction.TransactionStatus next) {
        // Simple logic: can't go back to INITIATED
        if (current == AurapayTransaction.TransactionStatus.COMPLETED
                || current == AurapayTransaction.TransactionStatus.FAILED) {
            return false;
        }
        return true;
    }
}
