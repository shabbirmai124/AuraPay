package com.aurapay.transaction.events;

import com.aurapay.transaction.entity.AurapayTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class TransactionEventPublisher {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    private static final String TOPIC_CREATED = "transaction-created";
    private static final String TOPIC_COMPLETED = "transaction-completed";
    private static final String TOPIC_FAILED = "transaction-failed";

    public void publishTransactionCreated(AurapayTransaction transaction) {
        kafkaTemplate.send(TOPIC_CREATED, transaction.getTransactionId(),
                "Transaction Created: " + transaction.getId());
    }

    public void publishTransactionCompleted(AurapayTransaction transaction) {
        kafkaTemplate.send(TOPIC_COMPLETED, transaction.getTransactionId(),
                "Transaction Completed: " + transaction.getId());
    }

    public void publishTransactionFailed(AurapayTransaction transaction, String reason) {
        kafkaTemplate.send(TOPIC_FAILED, transaction.getTransactionId(),
                "Transaction Failed: " + transaction.getId() + " Reason: " + reason);
    }
}
