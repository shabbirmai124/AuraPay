package com.aurapay.auth.service;

import com.aurapay.auth.entity.UserCredential;
import com.aurapay.auth.repository.UserCredentialRepository;
import com.aurapay.auth.security.JwtProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class AuthService {

    @Autowired
    private UserCredentialRepository repository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtProvider jwtProvider;

    @Autowired
    private AuthenticationManager authenticationManager;

    public String saveUser(UserCredential credential) {
        credential.setPassword(passwordEncoder.encode(credential.getPassword()));
        credential.setRoles(Set.of("ROLE_USER")); // Default role
        repository.save(credential);
        return "User added to the system";
    }

    public String generateToken(String username, String password) {
        Authentication authenticate = authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(username, password));
        return jwtProvider.generateToken(authenticate);
    }

    public void validateToken(String token) {
        jwtProvider.validateJwtToken(token);
    }
}
