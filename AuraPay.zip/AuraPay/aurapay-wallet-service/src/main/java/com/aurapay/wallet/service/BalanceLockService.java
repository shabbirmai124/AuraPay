package com.aurapay.wallet.service;

import com.aurapay.wallet.entity.AurapayWallet;
import com.aurapay.wallet.entity.CurrencyBalance;
import com.aurapay.wallet.repository.CurrencyBalanceRepository;
import com.aurapay.wallet.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class BalanceLockService {

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private CurrencyBalanceRepository balanceRepository;

    @Transactional
    public boolean lockFunds(Long userId, String currency, BigDecimal amount) {
        AurapayWallet wallet = walletRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        CurrencyBalance balance = balanceRepository.findByWalletIdAndCurrency(wallet.getId(), currency)
                .orElseThrow(() -> new RuntimeException("Balance not found"));

        if (balance.getAmount().compareTo(amount) >= 0) {
            balance.setAmount(balance.getAmount().subtract(amount));
            balance.setLockedAmount(balance.getLockedAmount().add(amount));
            balanceRepository.save(balance);
            return true;
        }
        return false;
    }

    @Transactional
    public void releaseFunds(Long userId, String currency, BigDecimal amount) {
        AurapayWallet wallet = walletRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        CurrencyBalance balance = balanceRepository.findByWalletIdAndCurrency(wallet.getId(), currency)
                .orElseThrow(() -> new RuntimeException("Balance not found"));

        balance.setLockedAmount(balance.getLockedAmount().subtract(amount));
        balance.setAmount(balance.getAmount().add(amount));
        balanceRepository.save(balance);
    }

    @Transactional
    public void captureFunds(Long userId, String currency, BigDecimal amount) {
        AurapayWallet wallet = walletRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        CurrencyBalance balance = balanceRepository.findByWalletIdAndCurrency(wallet.getId(), currency)
                .orElseThrow(() -> new RuntimeException("Balance not found"));

        balance.setLockedAmount(balance.getLockedAmount().subtract(amount));
        balanceRepository.save(balance);
    }
}
