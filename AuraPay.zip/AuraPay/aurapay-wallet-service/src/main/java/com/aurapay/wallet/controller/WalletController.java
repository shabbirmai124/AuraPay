package com.aurapay.wallet.controller;

import com.aurapay.wallet.entity.AurapayWallet;
import com.aurapay.wallet.entity.CurrencyBalance;
import com.aurapay.wallet.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/wallets")
public class WalletController {

    @Autowired
    private WalletService walletService;

    @PostMapping("/{userId}")
    public ResponseEntity<AurapayWallet> createWallet(@PathVariable Long userId) {
        return ResponseEntity.ok(walletService.createWallet(userId));
    }

    @PostMapping("/{userId}/deposit")
    public ResponseEntity<AurapayWallet> deposit(@PathVariable Long userId, @RequestParam String currency,
            @RequestParam BigDecimal amount) {
        return ResponseEntity.ok(walletService.deposit(userId, currency, amount));
    }

    @GetMapping("/{userId}/balance")
    public ResponseEntity<CurrencyBalance> getBalance(@PathVariable Long userId, @RequestParam String currency) {
        return ResponseEntity.ok(walletService.getBalance(userId, currency));
    }
}
