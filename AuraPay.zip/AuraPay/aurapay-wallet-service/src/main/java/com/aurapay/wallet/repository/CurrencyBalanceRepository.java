package com.aurapay.wallet.repository;

import com.aurapay.wallet.entity.CurrencyBalance;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CurrencyBalanceRepository extends JpaRepository<CurrencyBalance, Long> {
    Optional<CurrencyBalance> findByWalletIdAndCurrency(Long walletId, String currency);
}
