package com.aurapay.wallet.service;

import com.aurapay.wallet.entity.AurapayWallet;
import com.aurapay.wallet.entity.CurrencyBalance;
import com.aurapay.wallet.repository.CurrencyBalanceRepository;
import com.aurapay.wallet.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;

@Service
public class WalletService {

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private CurrencyBalanceRepository balanceRepository;

    @Transactional
    public AurapayWallet createWallet(Long userId) {
        AurapayWallet wallet = AurapayWallet.builder()
                .userId(userId)
                .status("ACTIVE")
                .balances(new ArrayList<>())
                .build();
        return walletRepository.save(wallet);
    }

    @Transactional
    public AurapayWallet deposit(Long userId, String currency, BigDecimal amount) {
        AurapayWallet wallet = walletRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        CurrencyBalance balance = balanceRepository.findByWalletIdAndCurrency(wallet.getId(), currency)
                .orElseGet(() -> {
                    CurrencyBalance newBalance = CurrencyBalance.builder()
                            .currency(currency)
                            .amount(BigDecimal.ZERO)
                            .lockedAmount(BigDecimal.ZERO)
                            .wallet(wallet)
                            .build();
                    wallet.getBalances().add(newBalance);
                    return balanceRepository.save(newBalance);
                });

        balance.setAmount(balance.getAmount().add(amount));
        balanceRepository.save(balance);
        return wallet;
    }

    public CurrencyBalance getBalance(Long userId, String currency) {
        AurapayWallet wallet = walletRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));
        return balanceRepository.findByWalletIdAndCurrency(wallet.getId(), currency)
                .orElseThrow(() -> new RuntimeException("Balance not found"));
    }
}
