package com.aurapay.wallet.repository;

import com.aurapay.wallet.entity.AurapayWallet;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface WalletRepository extends JpaRepository<AurapayWallet, Long> {
    Optional<AurapayWallet> findByUserId(Long userId);
}
