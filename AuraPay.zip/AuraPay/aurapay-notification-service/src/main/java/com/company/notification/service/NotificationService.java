package com.company.notification.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    @Autowired
    private EmailService emailService;

    @KafkaListener(topics = "transaction-created", groupId = "notification_group")
    public void consumeTransactionCreated(String message) {
        emailService.sendEmail("user@example.com", "Transaction Created", "Details: " + message);
    }

    @KafkaListener(topics = "transaction-completed", groupId = "notification_group")
    public void consumeTransactionCompleted(String message) {
        emailService.sendEmail("user@example.com", "Transaction Completed", "Details: " + message);
    }

    @KafkaListener(topics = "fraud-detected", groupId = "notification_group")
    public void consumeFraudDetected(String message) {
        emailService.sendEmail("admin@example.com", "FRAUD ALERT", "Details: " + message);
    }
}
