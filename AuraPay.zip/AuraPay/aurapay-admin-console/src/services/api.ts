import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080'; // API Gateway

const api = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

export const authService = {
    login: (credentials: any) => api.post('/auth/token', credentials),
    register: (user: any) => api.post('/auth/register', user),
};

export const fraudService = {
    checkFraud: (params: any) => api.get('/fraud/check', { params }),
};

export const complianceService = {
    screenTransaction: (params: any) => api.post('/compliance/screen', null, { params }),
};

export default api;
