package com.aurapay.ledger.service;

import com.aurapay.ledger.repository.LedgerEntryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class ReconciliationService {

    private final LedgerEntryRepository ledgerEntryRepository;
    // private final WalletService walletService; 

    @Scheduled(cron = "0 0 2 * * ?") // 2 AM Nightly
    public void runNightlyReconciliation() {
        log.info("Starting Nightly Reconciliation Job...");

        // Strategy:
        // 1. Aggregate all Ledger Entries by Wallet ID
        // 2. Compare calculated balance with current Wallet Balance
        // 3. Alert on mismatches

        /*
        List<WalletBalanceStats> stats = ledgerEntryRepository.aggregateBalances();
        for (WalletBalanceStats stat : stats) {
            BigDecimal actualBalance = walletService.getBalance(stat.getWalletId());
            if (stat.getCalculatedBalance().compareTo(actualBalance) != 0) {
                log.error("MISMATCH DETECTED for Wallet {}: Ledger={}, Wallet={}", 
                    stat.getWalletId(), stat.getCalculatedBalance(), actualBalance);
                // Trigger PagerDuty / Alert
            }
        }
        */
        
        log.info("Reconciliation Job Completed.");
    }
}
