package com.aurapay.ledger.controller;

import com.aurapay.ledger.dto.LedgerTransactionRequest;
import com.aurapay.ledger.entity.AurapayLedgerEntry;
import com.aurapay.ledger.entity.JournalEntry;
import com.aurapay.ledger.service.LedgerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/ledger")
@RequiredArgsConstructor
public class LedgerController {

    private final LedgerService ledgerService;

    @PostMapping("/transactions")
    public ResponseEntity<JournalEntry> recordTransaction(@RequestBody LedgerTransactionRequest request) {
        // Map DTO to Entity (Simplified mapping for MVP)
        List<AurapayLedgerEntry> entries = request.getEntries().stream()
                .map(e -> AurapayLedgerEntry.builder()
                        .walletId(e.getWalletId())
                        .amount(e.getAmount())
                        .type(AurapayLedgerEntry.EntryType.valueOf(e.getType()))
                        .currency(e.getCurrency())
                        .referenceId(e.getReferenceId())
                        .build())
                .collect(Collectors.toList());

        JournalEntry journal = ledgerService.recordTransaction(
                request.getTransactionId(), 
                request.getDescription(), 
                entries
        );
        return ResponseEntity.ok(journal);
    }
}
