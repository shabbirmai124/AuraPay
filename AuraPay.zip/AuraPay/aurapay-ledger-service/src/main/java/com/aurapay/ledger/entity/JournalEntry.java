package com.aurapay.ledger.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "journal_entries")
public class JournalEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String transactionId; // Reference to Transaction Service

    private String description;
    
    @Column(nullable = false)
    private BigDecimal totalDebit;

    @Column(nullable = false)
    private BigDecimal totalCredit;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private JournalStatus status;

    @Column(nullable = false, updatable = false)
    private LocalDateTime postedAt;

    @OneToMany(mappedBy = "journalEntry", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<AurapayLedgerEntry> entries;

    @PrePersist
    protected void onCreate() {
        postedAt = LocalDateTime.now();
        if (status == null) {
            status = JournalStatus.PENDING;
        }
    }

    public enum JournalStatus {
        PENDING, COMMITTED, ROLLED_BACK, FAILED
    }
}
