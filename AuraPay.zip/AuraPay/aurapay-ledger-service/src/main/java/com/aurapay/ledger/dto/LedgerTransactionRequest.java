package com.aurapay.ledger.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LedgerTransactionRequest {
    private String transactionId;
    private String description;
    private List<LedgerEntryRequest> entries;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LedgerEntryRequest {
        private Long walletId;
        private BigDecimal amount;
        private String type; // DEBIT, CREDIT
        private String currency;
        private String referenceId;
    }
}
