package com.aurapay.ledger.service;

import com.aurapay.ledger.entity.AurapayLedgerEntry;
import com.aurapay.ledger.entity.JournalEntry;
import com.aurapay.ledger.repository.JournalEntryRepository;
// import com.aurapay.ledger.repository.WalletRepository; // Assuming remote call or simple module
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class LedgerService {

    private final JournalEntryRepository journalEntryRepository;
    // private final WalletService walletService; // In a real microservice, this might be a Feign client

    @Transactional
    public JournalEntry recordTransaction(String transactionId, String description, List<AurapayLedgerEntry> entries) {
        log.info("Recording transaction: {}", transactionId);

        // 1. Validate Transaction ID idempotency
        if (journalEntryRepository.existsByTransactionId(transactionId)) {
            throw new IllegalArgumentException("Transaction already exists: " + transactionId);
        }

        // 2. Calculate Totals
        BigDecimal totalDebit = BigDecimal.ZERO;
        BigDecimal totalCredit = BigDecimal.ZERO;

        for (AurapayLedgerEntry entry : entries) {
            if (entry.getType() == AurapayLedgerEntry.EntryType.DEBIT) {
                totalDebit = totalDebit.add(entry.getAmount());
            } else {
                totalCredit = totalCredit.add(entry.getAmount());
            }
        }

        // 3. Verify Double-Entry Accounting Rule
        if (totalDebit.compareTo(totalCredit) != 0) {
            log.error("Transaction unbalanced: Debit={}, Credit={}", totalDebit, totalCredit);
            throw new IllegalStateException("Transaction is not balanced. Debit must equal Credit.");
        }

        // 4. Create Journal Entry
        JournalEntry journal = JournalEntry.builder()
                .transactionId(transactionId)
                .description(description)
                .totalDebit(totalDebit)
                .totalCredit(totalCredit)
                .status(JournalEntry.JournalStatus.PENDING)
                .build();

        // 5. Link Entries to Journal
        for (AurapayLedgerEntry entry : entries) {
            entry.setJournalEntry(journal);
            entry.setTransactionId(transactionId);
        }
        journal.setEntries(entries);

        // 6. Save (ACID)
        JournalEntry savedJournal = journalEntryRepository.save(journal);
        
        // 7. Execute Wallet Updates (Here we assume success or rollback entire transaction)
        // In a distributed system, this might involve SAGA or 2PC. 
        // For "Bank-Grade" strictly within the ledger, we just persist the rigid record here.
        // The balance update logic usually listens to this or is called synchronously.
        
        savedJournal.setStatus(JournalEntry.JournalStatus.COMMITTED);
        return journalEntryRepository.save(savedJournal);
    }
}
