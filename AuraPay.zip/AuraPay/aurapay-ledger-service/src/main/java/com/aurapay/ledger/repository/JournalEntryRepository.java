package com.aurapay.ledger.repository;

import com.aurapay.ledger.entity.JournalEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface JournalEntryRepository extends JpaRepository<JournalEntry, Long> {
    Optional<JournalEntry> findByTransactionId(String transactionId);
}
