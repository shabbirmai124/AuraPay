package com.aurapay.ledger.repository;

import com.aurapay.ledger.entity.AurapayLedgerEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LedgerEntryRepository extends JpaRepository<AurapayLedgerEntry, Long> {
    List<AurapayLedgerEntry> findByWalletId(Long walletId);
}
