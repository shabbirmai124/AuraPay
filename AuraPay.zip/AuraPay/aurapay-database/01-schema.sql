-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    phone_number VARCHAR(50),
    status VARCHAR(50) DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Wallets Table
CREATE TABLE IF NOT EXISTS wallets (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    status VARCHAR(50) NOT NULL,
    CONSTRAINT fk_wallet_user FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Currency Balances Table
CREATE TABLE IF NOT EXISTS currency_balances (
    id BIGSERIAL PRIMARY KEY,
    wallet_id BIGINT NOT NULL,
    currency VARCHAR(10) NOT NULL,
    available_balance DECIMAL(19, 4) NOT NULL DEFAULT 0.0000,
    locked_balance DECIMAL(19, 4) NOT NULL DEFAULT 0.0000,
    version BIGINT DEFAULT 0,
    CONSTRAINT fk_balance_wallet FOREIGN KEY (wallet_id) REFERENCES wallets(id)
);

-- Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
    id BIGSERIAL PRIMARY KEY,
    transaction_id VARCHAR(255) NOT NULL UNIQUE,
    user_id BIGINT NOT NULL,
    sender_wallet_id BIGINT,
    receiver_wallet_id BIGINT,
    amount DECIMAL(19, 4) NOT NULL,
    currency VARCHAR(10),
    status VARCHAR(50),
    failure_reason TEXT,
    idempotency_key VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Fraud Logs Table
CREATE TABLE IF NOT EXISTS fraud_logs (
    id BIGSERIAL PRIMARY KEY,
    transaction_id VARCHAR(255),
    user_id BIGINT,
    amount DECIMAL(19, 4),
    ip_address VARCHAR(50),
    risk_score INT,
    reason VARCHAR(255),
    checked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
