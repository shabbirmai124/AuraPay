-- Insert Users
INSERT INTO users (email, first_name, last_name, phone_number, status) VALUES
('alice@example.com', 'Alice', 'Wonderland', '+1234567890', 'ACTIVE'),
('bob@example.com', 'Bob', 'Builder', '+0987654321', 'ACTIVE');

-- Insert Wallets
INSERT INTO wallets (user_id, status) VALUES
((SELECT id FROM users WHERE email = 'alice@example.com'), 'ACTIVE'),
((SELECT id FROM users WHERE email = 'bob@example.com'), 'ACTIVE');

-- Insert Balances for Alice
INSERT INTO currency_balances (wallet_id, currency, available_balance, locked_balance) VALUES
((SELECT id FROM wallets WHERE user_id = (SELECT id FROM users WHERE email = 'alice@example.com')), 'USD', 1000.00, 0.00),
((SELECT id FROM wallets WHERE user_id = (SELECT id FROM users WHERE email = 'alice@example.com')), 'EUR', 500.00, 0.00);

-- Insert Balances for Bob
INSERT INTO currency_balances (wallet_id, currency, available_balance, locked_balance) VALUES
((SELECT id FROM wallets WHERE user_id = (SELECT id FROM users WHERE email = 'bob@example.com')), 'USD', 50.00, 0.00);
