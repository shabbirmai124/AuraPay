# AuraPay Database

This directory contains initialization scripts for the AuraPay PostgreSQL database.

## Structure

- `00-init.sql`: Enables necessary extensions (e.g., `uuid-ossp`).
- `01-schema.sql`: Defines the database schema (tables, constraints).
- `02-seed-data.sql`: Populates the database with initial test data.

## Usage

These scripts are automatically executed by the PostgreSQL Docker container when the volume is created for the first time. They are mounted to `/docker-entrypoint-initdb.d/`.

To reset the database, remove the associated Docker volume:
```bash
docker-compose down -v
docker-compose up -d
```
