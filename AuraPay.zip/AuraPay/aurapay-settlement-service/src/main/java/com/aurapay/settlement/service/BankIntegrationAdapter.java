package com.company.settlement.service;

import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class BankIntegrationAdapter {

    public boolean processBankTransfer(String accountId, BigDecimal amount, String currency) {
        // Mock Bank API call
        System.out.println("Processing bank transfer to " + accountId + " for " + amount + " " + currency);
        return true;
    }
}
