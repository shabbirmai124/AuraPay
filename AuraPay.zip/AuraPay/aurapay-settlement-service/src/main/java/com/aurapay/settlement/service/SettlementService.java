package com.company.settlement.service;

import com.company.settlement.entity.SettlementBatch;
import com.company.settlement.repository.SettlementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.UUID;

@Service
public class SettlementService {

    @Autowired
    private SettlementRepository repository;

    @Autowired
    private BankIntegrationAdapter bankAdapter;

    public SettlementBatch createBatch(String currency, BigDecimal amount) {
        SettlementBatch batch = SettlementBatch.builder()
                .batchId(UUID.randomUUID().toString())
                .currency(currency)
                .totalAmount(amount)
                .status("PENDING")
                .build();
        return repository.save(batch);
    }

    public SettlementBatch processBatch(Long batchId) {
        SettlementBatch batch = repository.findById(batchId)
                .orElseThrow(() -> new RuntimeException("Batch not found"));

        // Logic to simulate processing
        boolean success = bankAdapter.processBankTransfer("BankPoolAccount", batch.getTotalAmount(),
                batch.getCurrency());

        if (success) {
            batch.setStatus("PROCESSED");
        } else {
            batch.setStatus("FAILED");
        }

        return repository.save(batch);
    }
}
