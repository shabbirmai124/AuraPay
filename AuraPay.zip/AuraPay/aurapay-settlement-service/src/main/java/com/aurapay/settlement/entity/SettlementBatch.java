package com.company.settlement.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "settlement_batches")
public class SettlementBatch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String batchId;
    private LocalDateTime settlementDate;
    private String status; // PENDING, PROCESSED, FAILED
    private BigDecimal totalAmount;
    private String currency;

    @PrePersist
    protected void onCreate() {
        settlementDate = LocalDateTime.now();
    }
}
