package com.company.settlement.repository;

import com.company.settlement.entity.SettlementBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SettlementRepository extends JpaRepository<SettlementBatch, Long> {
}
