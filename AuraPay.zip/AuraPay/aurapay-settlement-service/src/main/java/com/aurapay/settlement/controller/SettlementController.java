package com.company.settlement.controller;

import com.company.settlement.entity.SettlementBatch;
import com.company.settlement.service.SettlementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/settlement")
public class SettlementController {

    @Autowired
    private SettlementService service;

    @PostMapping("/create")
    public ResponseEntity<SettlementBatch> createBatch(@RequestParam String currency, @RequestParam BigDecimal amount) {
        return ResponseEntity.ok(service.createBatch(currency, amount));
    }

    @PostMapping("/{batchId}/process")
    public ResponseEntity<SettlementBatch> processBatch(@PathVariable Long batchId) {
        return ResponseEntity.ok(service.processBatch(batchId));
    }
}
