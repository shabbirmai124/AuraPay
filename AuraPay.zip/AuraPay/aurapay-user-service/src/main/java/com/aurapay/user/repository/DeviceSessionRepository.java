package com.aurapay.user.repository;

import com.aurapay.user.entity.DeviceSession;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DeviceSessionRepository extends JpaRepository<DeviceSession, Long> {
    List<DeviceSession> findByUserId(Long userId);
}
