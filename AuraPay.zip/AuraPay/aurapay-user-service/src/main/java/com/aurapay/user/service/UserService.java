package com.aurapay.user.service;

import com.aurapay.user.entity.User;
import com.aurapay.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public User getUser(Long id) {
        return userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
    }

    public User updateUserStatus(Long id, String status) {
        User user = getUser(id);
        user.setStatus(status);
        return userRepository.save(user);
    }
}
