package com.aurapay.fx.repository;

import com.aurapay.fx.entity.AurapayFxRate;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ExchangeRateRepository extends JpaRepository<AurapayFxRate, Long> {
    Optional<AurapayFxRate> findTopByFromCurrencyAndToCurrencyOrderByValidUntilDesc(String from, String to);
}
