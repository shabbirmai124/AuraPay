package com.aurapay.fx.service;

import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class RateProviderAdapter {

    // Mock implementation of external rate provider
    public BigDecimal fetchRate(String from, String to) {
        if (from.equals("USD") && to.equals("EUR"))
            return new BigDecimal("0.85");
        if (from.equals("EUR") && to.equals("USD"))
            return new BigDecimal("1.18");
        return BigDecimal.ONE;
    }
}
