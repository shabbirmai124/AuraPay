package com.aurapay.fx.controller;

import com.aurapay.fx.entity.AurapayFxRate;
import com.aurapay.fx.service.FxService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/fx")
public class FxController {

    @Autowired
    private FxService service;

    @GetMapping("/rate")
    public ResponseEntity<AurapayFxRate> getRate(@RequestParam String from, @RequestParam String to) {
        return ResponseEntity.ok(service.getRate(from, to));
    }

    @GetMapping("/convert")
    public ResponseEntity<BigDecimal> convert(@RequestParam String from, @RequestParam String to,
            @RequestParam BigDecimal amount) {
        return ResponseEntity.ok(service.convert(from, to, amount));
    }
}
