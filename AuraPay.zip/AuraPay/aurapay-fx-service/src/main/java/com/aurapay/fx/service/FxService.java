package com.aurapay.fx.service;

import com.aurapay.fx.entity.AurapayFxRate;
import com.aurapay.fx.repository.ExchangeRateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Service
public class FxService {

    @Autowired
    private ExchangeRateRepository repository;

    @Autowired
    private RateProviderAdapter rateProvider;

    public AurapayFxRate getRate(String from, String to) {
        return repository.findTopByFromCurrencyAndToCurrencyOrderByValidUntilDesc(from, to)
                .filter(rate -> rate.getValidUntil().isAfter(LocalDateTime.now()))
                .orElseGet(() -> fetchAndSaveRate(from, to));
    }

    private AurapayFxRate fetchAndSaveRate(String from, String to) {
        BigDecimal rate = rateProvider.fetchRate(from, to);
        AurapayFxRate exchangeRate = AurapayFxRate.builder()
                .fromCurrency(from)
                .toCurrency(to)
                .rate(rate)
                .build();
        return repository.save(exchangeRate);
    }

    public BigDecimal convert(String from, String to, BigDecimal amount) {
        AurapayFxRate rate = getRate(from, to);
        return amount.multiply(rate.getRate());
    }
}
