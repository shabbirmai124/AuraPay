package com.company.compliance.service;

import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class AMLService {

    public boolean requiresReporting(BigDecimal amount) {
        // AML Rule: Report transactions over 10,000
        return amount.compareTo(new BigDecimal("10000")) >= 0;
    }
}
