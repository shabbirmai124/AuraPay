package com.company.compliance.repository;

import com.company.compliance.entity.ComplianceReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComplianceReportRepository extends JpaRepository<ComplianceReport, Long> {
}
