package com.company.compliance.service;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SanctionScreeningService {

    private List<String> sanctionedCountries = List.of("NORTH KOREA", "IRAN");
    private List<String> sanctionedUsers = List.of("BadActor123");

    public boolean isSanctioned(Long userId, String country) {
        if (sanctionedCountries.contains(country.toUpperCase()))
            return true;
        // Mock checking user against list
        return false;
    }
}
