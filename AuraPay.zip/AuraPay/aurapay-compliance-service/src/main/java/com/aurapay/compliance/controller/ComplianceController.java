package com.company.compliance.controller;

import com.company.compliance.entity.ComplianceReport;
import com.company.compliance.repository.ComplianceReportRepository;
import com.company.compliance.service.AMLService;
import com.company.compliance.service.SanctionScreeningService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/compliance")
public class ComplianceController {

    @Autowired
    private AMLService amlService;

    @Autowired
    private SanctionScreeningService sanctionService;

    @Autowired
    private ComplianceReportRepository repository;

    @PostMapping("/screen")
    public ResponseEntity<ComplianceReport> screenTransaction(@RequestParam String transactionId,
            @RequestParam Long userId,
            @RequestParam BigDecimal amount,
            @RequestParam String country) {

        String status = "PASSED";
        String details = "Clean";
        String checkType = "ALL";

        if (sanctionService.isSanctioned(userId, country)) {
            status = "BLOCKED";
            details = "Sanctioned Entity/Country";
            checkType = "SANCTION";
        } else if (amlService.requiresReporting(amount)) {
            status = "FLAGGED";
            details = "Exceeds Threshold";
            checkType = "AML";
        }

        ComplianceReport report = ComplianceReport.builder()
                .transactionId(transactionId)
                .userId(userId)
                .checkType(checkType)
                .status(status)
                .details(details)
                .build();

        return ResponseEntity.ok(repository.save(report));
    }
}
