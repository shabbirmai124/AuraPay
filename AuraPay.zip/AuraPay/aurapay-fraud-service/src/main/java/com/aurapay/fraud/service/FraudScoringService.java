package com.aurapay.fraud.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@Slf4j
@RequiredArgsConstructor
public class FraudScoringService {

    public FraudEvaluationResult evaluate(FraudContext context) {
        log.info("Evaluating fraud risk for transaction amount: {}", context.getAmount());

        // 1. Calculate Risk Factors (0-100)
        double amountRisk = calculateAmountRisk(context.getAmount());
        double velocityRisk = calculateVelocityRisk(context.getUserId());
        double geoRisk = calculateGeoRisk(context.getIpAddress());
        double deviceRisk = calculateDeviceRisk(context.getDeviceId());
        double ipRepRisk = calculateIpReputationRisk(context.getIpAddress());
        double kycRisk = calculateKycRisk(context.getUserId());
        double historyRisk = calculateHistoryRisk(context.getUserId());

        // 2. Apply Weighted Formula
        // Risk Score = (0.25 × Amount) + (0.20 × Velocity) + (0.15 × Geo) + (0.15 × Device) + (0.10 × IP) + (0.10 × KYC) + (0.05 × History)
        double score = (0.25 * amountRisk) +
                       (0.20 * velocityRisk) +
                       (0.15 * geoRisk) +
                       (0.15 * deviceRisk) +
                       (0.10 * ipRepRisk) +
                       (0.10 * kycRisk) +
                       (0.05 * historyRisk);

        log.info("Calculated Risk Score: {}", score);

        // 3. Determine Decision
        FraudDecisionEnum decision;
        if (score <= 30) {
            decision = FraudDecisionEnum.AUTO_APPROVE;
        } else if (score <= 60) {
            decision = FraudDecisionEnum.STEP_UP;
        } else if (score <= 80) {
            decision = FraudDecisionEnum.MANUAL_REVIEW;
        } else {
            decision = FraudDecisionEnum.AUTO_BLOCK;
        }

        return new FraudEvaluationResult(score, decision, "Score calculated based on weighted inputs");
    }

    private double calculateAmountRisk(BigDecimal amount) {
        // Simple logic: > $10,000 is high risk (100)
        if (amount.compareTo(new BigDecimal("10000")) > 0) return 100.0;
        if (amount.compareTo(new BigDecimal("1000")) > 0) return 50.0;
        return 10.0;
    }

    private double calculateVelocityRisk(String userId) {
        // TODO: Query transaction history count in last minute
        return 20.0; // Mock
    }

    private double calculateGeoRisk(String ipAddress) {
        // TODO: GeoIP lookup and distance check
        return 10.0; // Mock (Low risk)
    }

    private double calculateDeviceRisk(String deviceId) {
        // TODO: Check known bad devices
        return 5.0; 
    }

    private double calculateIpReputationRisk(String ipAddress) {
        // TODO: Check blacklists
        return 0.0;
    }

    private double calculateKycRisk(String userId) {
        // TODO: Check user KYC level (Level 1 = High Risk, Level 3 = Low Risk)
        return 10.0; // Assumed verified
    }

    private double calculateHistoryRisk(String userId) {
        // TODO: Check previous chargebacks
        return 0.0;
    }
}
