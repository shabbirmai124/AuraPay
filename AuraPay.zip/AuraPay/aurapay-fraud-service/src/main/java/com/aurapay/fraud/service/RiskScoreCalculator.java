package com.aurapay.fraud.service;

import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class RiskScoreCalculator {

    public int calculateScore(BigDecimal amount, String ipAddress) {
        int score = 0;
        if (amount.compareTo(new BigDecimal("10000")) > 0) {
            score += 50;
        }
        if (ipAddress != null && ipAddress.startsWith("192.168")) {
            // Internal IP, lower risk (example logic)
        } else {
            score += 10;
        }
        return score;
    }
}
