package com.aurapay.fraud.service;

import com.aurapay.fraud.entity.AurapayFraudLog;
import com.aurapay.fraud.repository.FraudLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class FraudEngine {

    @Autowired
    private FraudLogRepository repository;

    @Autowired
    private RiskScoreCalculator riskScoreCalculator;

    public boolean isFraudulent(String transactionId, Long userId, BigDecimal amount, String ipAddress) {
        int score = riskScoreCalculator.calculateScore(amount, ipAddress);

        AurapayFraudLog log = AurapayFraudLog.builder()
                .transactionId(transactionId)
                .userId(userId)
                .amount(amount)
                .ipAddress(ipAddress)
                .riskScore(score)
                .reason(score > 80 ? "High Risk Score" : "Safe")
                .build();
        repository.save(log);

        return score > 80; // Threshold
    }
}
