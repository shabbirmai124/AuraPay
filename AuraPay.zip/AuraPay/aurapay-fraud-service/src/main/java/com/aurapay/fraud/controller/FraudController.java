package com.aurapay.fraud.controller;

import com.aurapay.fraud.service.FraudContext;
import com.aurapay.fraud.service.FraudEvaluationResult;
import com.aurapay.fraud.service.FraudScoringService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fraud")
@RequiredArgsConstructor
public class FraudController {

    private final FraudScoringService fraudScoringService;

    @PostMapping("/check")
    public ResponseEntity<FraudEvaluationResult> checkFraud(@RequestBody FraudContext context) {
        return ResponseEntity.ok(fraudScoringService.evaluate(context));
    }
}
