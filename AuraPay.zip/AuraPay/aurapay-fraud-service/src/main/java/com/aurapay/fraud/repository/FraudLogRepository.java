package com.aurapay.fraud.repository;

import com.aurapay.fraud.entity.AurapayFraudLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FraudLogRepository extends JpaRepository<AurapayFraudLog, Long> {
}
