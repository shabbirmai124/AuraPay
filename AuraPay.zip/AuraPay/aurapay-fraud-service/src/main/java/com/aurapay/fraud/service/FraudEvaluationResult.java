package com.aurapay.fraud.service;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FraudEvaluationResult {
    private double score;
    private FraudDecisionEnum decision;
    private String reason;
}
