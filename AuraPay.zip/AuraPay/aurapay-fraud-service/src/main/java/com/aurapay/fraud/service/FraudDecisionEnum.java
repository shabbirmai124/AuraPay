package com.aurapay.fraud.service;

public enum FraudDecisionEnum {
    AUTO_APPROVE,
    STEP_UP,
    MANUAL_REVIEW,
    AUTO_BLOCK
}
